package com.example.rta_2019_4.ListViewProcess;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.rta_2019_4.Model.Data_Model;

import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {
    ArrayList<Data_Model> data_models;

    @Override
    public int getCount() {
        return data_models.size();
    }

    @Override
    public Object getItem(int position) {
        return data_models.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }
}
